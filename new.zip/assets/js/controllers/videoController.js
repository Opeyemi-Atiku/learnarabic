app.controller('videoController', function($scope, $location) {

});